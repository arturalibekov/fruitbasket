package com.testa;

import java.util.HashMap;
import java.util.Map;

public class SpanMap {

    private Map<Integer, Map<Integer, Span>> spans = new HashMap<>();
    
    public Span getSpan(int row, int col) {
        Span span = null;
        Map<Integer, Span> cols = spans.get(row);
        if (cols != null) {
            span = cols.get(col);
        }
        return span;
    }
    
    public void clear() {
        spans.clear();
    }
    
    public boolean isCellVisible(int row, int col) {
        Span span = getSpan(row, col);
        if (span == null || (span.getRowStart() == row && span.getColStart() == col) ){
            return true;
        }
        return false;
    }

    public void removeSpan(Span span) {
        for(int i=0 ; i < span.getRowSpan(); i++) {
            for(int j=0; j < span.getColSpan(); j++) {
                int row = span.getRowStart() + i;
                int col = span.getColStart() + j;
                Map<Integer, Span> colsMap = spans.get(row);
                if (colsMap == null) {
                    continue;
                }
                colsMap.remove(col);
            }
        }
    }
    
    public void addSpan(Span span) {
        if (span == null || (span.getColSpan() <= 1 && span.getRowSpan() <= 1)) {
            return;
        }
        for(int i=0 ; i < span.getRowSpan(); i++) {
            for(int j=0; j < span.getColSpan(); j++) {
                int row = span.getRowStart() + i;
                int col = span.getColStart() + j;
                Map<Integer, Span> colsMap = spans.get(row);
                if (colsMap == null) {
                    colsMap = new HashMap<>();
                    spans.put(row, colsMap);
                }
                colsMap.put(col, span);
            }
        }
    }
    
}
