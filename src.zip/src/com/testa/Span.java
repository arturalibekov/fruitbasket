package com.testa;

public class Span {

    private int colStart;
    private int colSpan;
    private int rowStart;
    private int rowSpan;
    
    public Span(int rowStart, int colStart) {
        this(rowStart, colStart, 1, 1);
    }
    
    public Span(int rowStart, int colStart, int rowSpan, int colSpan) {
        this.rowStart = rowStart;
        this.colStart = colStart;
        this.rowSpan = rowSpan;
        this.colSpan = colSpan;
    }
    
    public int getColStart() {
        return colStart;
    }


    public void setColStart(int colStart) {
        this.colStart = colStart;
    }


    public int getColSpan() {
        return colSpan;
    }


    public void setColSpan(int colSpan) {
        this.colSpan = colSpan;
    }


    public int getRowStart() {
        return rowStart;
    }


    public void setRowStart(int rowStart) {
        this.rowStart = rowStart;
    }


    public int getRowSpan() {
        return rowSpan;
    }


    public void setRowSpan(int rowSpan) {
        this.rowSpan = rowSpan;
    }

}
