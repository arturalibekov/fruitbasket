package com.testa;

import java.util.HashMap;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class Main {

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("Table");

//        ColSpanMap m = new TableColSpanMap();
//        HashMap<Integer, Integer> cellSpanMap = new HashMap<>();
//        cellSpanMap.put(0, 3);
//        cellSpanMap.put(4, 7);
//        cellSpanMap.put(9, 5);
//        m.setSpanMap(cellSpanMap);
        TableModel tm = new DefaultTableModel(2, 4) {
            @Override
            public Object getValueAt(int row, int column) {
                return "r" + row + ";c" + column;
            }
        };
        
        SpanMap spanMap = new SpanMap();
        spanMap.addSpan(new Span(1, 1, 1, 2));
        SpanTable table = new SpanTable(spanMap, tm);

        frame.getContentPane().add(new JScrollPane(table));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 295);
        frame.setVisible(true);
    }

    public static void main(String[] args) {

        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }

}
