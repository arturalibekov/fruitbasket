package com.testa;

import java.util.HashMap;

public interface ColSpanMap {
    int span(int row, int column);

    int visibleCell(int row, int column);

    void setSpanMap(HashMap<Integer, Integer> spanMap);

}