package com.testa;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JComponent;
import javax.swing.JTable;
import javax.swing.plaf.basic.BasicTableUI;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;

public class SpanTable extends JTable {

    private static final long serialVersionUID = 1L;

    private SpanMap spanMap;

    public SpanTable(SpanMap spanMap, TableModel tbl) {
        super(tbl);
        this.spanMap = spanMap;
        setUI(new SpanCellTableUI());
        getTableHeader().setReorderingAllowed(false);
    }
    
    @Override
    public Rectangle getCellRect(int row, int column, boolean includeSpacing) {
        Rectangle sRect = super.getCellRect(row,column,includeSpacing);
        if ((row <0) || (column<0) ||
            (getRowCount() <= row) || (getColumnCount() <= column)) {
            return sRect;
        }
        
        Span span = spanMap.getSpan(row, column);
        if (span == null) {
            System.out.println("row=" + row + ", column=" + column + "; rect=" + sRect);
            return sRect;
        }
        int startRow = span.getRowSpan();
        int startColumn = span.getColSpan(); 
        
        int index = 0;
        int columnMargin = getColumnModel().getColumnMargin();
        Rectangle cellFrame = new Rectangle();
        int aCellHeight = rowHeight + rowMargin;
        cellFrame.y = startRow * aCellHeight;
        cellFrame.height = span.getRowSpan() * aCellHeight;
        
        Enumeration<TableColumn> columns = getColumnModel().getColumns();
        while (columns.hasMoreElements()) {
          TableColumn aColumn = (TableColumn)columns.nextElement();
          cellFrame.width = aColumn.getWidth() + columnMargin;
          if (index == startColumn) {
              break;
          }
          cellFrame.x += cellFrame.width;
          index++;
        }
        for (int i = 0; i < span.getColSpan() - 1; i++) {
            if (columns.hasMoreElements()) {
                TableColumn aColumn = (TableColumn) columns.nextElement();
                cellFrame.width += aColumn.getWidth() + columnMargin;
            }
            break;
        }        

        if (!includeSpacing) {
          Dimension spacing = getIntercellSpacing();
          cellFrame.setBounds(cellFrame.x + spacing.width / 2, cellFrame.y + spacing.height / 2, cellFrame.width - spacing.width, cellFrame.height - spacing.height);
        }
        System.out.println("* row=" + row + ", column=" + column + "; rect=" + sRect);
        return cellFrame;
      }
      

    private Span getSpanAtPoint(Point point) {
        int row = point.y / (rowHeight + rowMargin);
        if ((row < 0) || (getRowCount() <= row)) {
            return null;
        }
        int column = getColumnModel().getColumnIndexAtX(point.x);
        return spanMap.getSpan(row, column);
    }
    
    @Override
    public int rowAtPoint(Point point) {
        int row = super.rowAtPoint(point);
        Span span = getSpanAtPoint(point);
        return span != null ? span.getRowStart() : row;
    }
    
    @Override
    public int columnAtPoint(Point point) {
        int column = super.columnAtPoint(point);
        Span span = getSpanAtPoint(point);
        return span != null ? span.getColStart() : column;
    }
    
    
    
    /**
     * Span cell painter
     */
    private class SpanCellTableUI extends BasicTableUI {
        
        public void paint(Graphics graphics, JComponent component) {
            Rectangle oldClipBounds = graphics.getClipBounds();
            Rectangle clipBounds = new Rectangle(oldClipBounds);
            int tableWidth = table.getColumnModel().getTotalColumnWidth();
            clipBounds.width = Math.min(clipBounds.width, tableWidth);
            graphics.setClip(clipBounds);
            int firstIndex = table.rowAtPoint(new Point(0, clipBounds.y));
            int lastIndex = table.getRowCount() - 1;
            Rectangle rowRect = new Rectangle(0, 0, tableWidth, table.getRowHeight() + table.getRowMargin());
            rowRect.y = firstIndex * rowRect.height;
            for (int index = firstIndex; index <= lastIndex; index++) {
                if (rowRect.intersects(clipBounds)) {
                    paintRow(graphics, index);
                }
                rowRect.y += rowRect.height;
            }
            graphics.setClip(oldClipBounds);
        }

        private void paintRow(Graphics g, int row) {
            Rectangle rect = g.getClipBounds();
            boolean drawn = false;
            int numColumns = table.getColumnCount();
            for (int column = 0; column < numColumns; column++) {
                Rectangle cellRect = table.getCellRect(row, column, true);
                int cellRow, cellColumn;
                Span span = spanMap.getSpan(row, column);
                if (span != null) {
                    cellRow = span.getRowStart();
                    cellColumn = span.getColSpan();
                } else {
                    cellRow = row;
                    cellColumn = column;
                }
                if (cellRect.intersects(rect)) {
                    drawn = true;
                    paintCell(g, cellRect, cellRow, cellColumn);
                } else {
                    if (drawn)
                        break;
                }
            }
        }

        private void paintCell(Graphics graphics, Rectangle cellRect, int row, int column) {
            int spacingHeight = table.getRowMargin();
            int spacingWidth = table.getColumnModel().getColumnMargin();
            Color color = graphics.getColor();
            graphics.setColor(table.getGridColor());
            graphics.drawRect(cellRect.x, cellRect.y, cellRect.width - 1, cellRect.height - 1);
            graphics.setColor(color);

            cellRect.setBounds(cellRect.x + spacingWidth / 2, cellRect.y + spacingHeight / 2, cellRect.width - spacingWidth, cellRect.height - spacingHeight);

            if (table.isEditing() && table.getEditingRow() == row && table.getEditingColumn() == column) {
                Component component = table.getEditorComponent();
                component.setBounds(cellRect);
                component.validate();
            } else {
                TableCellRenderer renderer = table.getCellRenderer(row, column);
                Component component = table.prepareRenderer(renderer, row, column);
                if (component.getParent() == null) {
                    rendererPane.add(component);
                }
                rendererPane.paintComponent(graphics, component, table, cellRect.x, cellRect.y, cellRect.width, cellRect.height, true);
            }
        }
    }
}
